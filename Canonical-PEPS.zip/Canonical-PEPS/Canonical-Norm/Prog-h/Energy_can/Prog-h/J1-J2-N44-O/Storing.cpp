#include"Header.h"

void Storing(cx_mat* Itop,cx_mat* TI)
{
TI[0]=Itop[0];
}
